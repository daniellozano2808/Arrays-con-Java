/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.evertec.resolucionarreglos.process;

import co.com.evertec.resolucionarreglos.util.ArrayConvertor;
import co.com.evertec.resolucionarreglos.util.Printer;
import com.sun.org.apache.xalan.internal.xsltc.util.IntegerArray;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Optional;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class MainProcess {

    /**
     * Método principal para iniciar la aplicación
     *
     * @param args
     */
    public static void main(String[] args) {
        String opcionIngresada = null;
        do {
            OptionsMenu.showOptionsMenu();
            Scanner input = new Scanner(System.in);
            System.out.println("Ingrese opción: ");
            opcionIngresada = input.nextLine();
            validateInput(opcionIngresada);
            
        } while (!opcionIngresada.toLowerCase().equals("esc"));
    }

    /**
     * Método encargado de realizar la validación de la función ingresada y de
     * llamar al método correspondiente
     *
     * @param option Texto capturado por consola
     * @return Nos indica si la opción ingresada por consola es valida y se
     * puede procesar
     */
    private static void validateInput(String option) {
        String[] optionSplit = option.split(" ");

        //Validamos que el input ingresado tenga un tamaño superior a uno
        //después de hacerle split, es decir, que esté la función a ejecutar
        //y adicional que hayan parámetros para operar
        if (optionSplit.length > 1) {
            switch (optionSplit[0]) {
                case "OA":
                    ascendentOrden(ArrayConvertor.convertStringArrayToIntegerArray(optionSplit, 1));
                    break;
                case "OD":
                    descendenteOrden(ArrayConvertor.convertStringArrayToIntegerArray(optionSplit, 1));
                    break;
                case "NM":
                    mayor(ArrayConvertor.convertStringArrayToIntegerArray(optionSplit, 1));
                    break;
                case "NMN":
                    menor(ArrayConvertor.convertStringArrayToIntegerArray(optionSplit, 1));
                    break;
                case "VS":
                    sumarValores(ArrayConvertor.convertStringArrayToIntegerArray(optionSplit, 1));
                    break;
                default:
                    Printer.printMessage("Opción inválida");
                    break;
            }
        }
    }

    /**
     * Método encargado de llamar la operación NM. Mediante el uso de Streams
     * podemos realizar la búsqueda del número mayor
     *
     * @param integerArray
     */
    private static void mayor(Integer[] integerArray) {
        Optional<Integer> maxNumber = Arrays.stream(integerArray).max(Comparator.naturalOrder());
        if (maxNumber.isPresent()) {
            Printer.printMessage("El número mayor es " + maxNumber.get());
        }
    }

    /**
     * Método encargado de llamar la operación NMN. Mediante el uso de Streams
     * podemos realizar la búsqueda del número menor
     *
     * @param integerArray
     */
    private static void menor(Integer[] integerArray) {
        Optional<Integer> minNumber = Arrays.stream(integerArray).min(Comparator.naturalOrder());
        if (minNumber.isPresent()) {
            Printer.printMessage("El número menor es " + minNumber.get());
        }
    }

    /**
     * Método encargado de llamar la operación OA. Mediante el uso de sort
     * podemos realizar el ordenamiento de un array de manera ascendente
     *
     * @param integerArray
     */
    private static void ascendentOrden(Integer[] integerArray) {
        Arrays.sort(integerArray);
        Printer.printMessage(Arrays.toString(integerArray) + " --> Lista de Valores Ordenados Ascendentemente");
    }

    /**
     * Método encargado de llamar la operación OD. Mediante el uso de sort
     * podemos realizar el ordenamiento de un array de manera ascendente
     *
     * @param integerArray
     */
    private static void descendenteOrden(Integer[] integerArray) {
        Arrays.sort(integerArray, Collections.reverseOrder());
        Printer.printMessage(Arrays.toString(integerArray) + " --> Lista de Valores Ordenados Descendentemente");
    }

    /**
     * Método encargado de llamar la operación VS. Mediante el uso de la
     * recursividad podemos realizar la suma de los elementos de un array
     *
     * @param integerArray
     */
    public static int sumarValores(Integer[] integerArray) {
        int suma = 0;
        for (int i = 0; i < integerArray.length; i++) {
            suma += integerArray[i];
        }
        Printer.printMessage("La suma del arreglo es: " + suma);
        return 0;
    }
}
