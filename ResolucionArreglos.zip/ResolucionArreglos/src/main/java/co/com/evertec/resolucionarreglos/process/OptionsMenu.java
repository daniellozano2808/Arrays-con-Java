/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.evertec.resolucionarreglos.process;

import co.com.evertec.resolucionarreglos.util.Printer;

/**
 *
 * @author USER
 */
public class OptionsMenu {
    
    public static void showOptionsMenu() {
        Printer.printMessage("===============================================");
        Printer.printMessage("Opciones de Menú, ingrese la sigla de la función que desea realizar");
        Printer.printMessage("(OA) - Ordenar la lista Ascendentemente");
        Printer.printMessage("(OD) - Orden la lista Descendentemente");
        Printer.printMessage("(NM) - Obtener el número mayor");
        Printer.printMessage("(NMN) - Obtener el número menor");
        Printer.printMessage("(VS) - Obtener la suma de los valores");
        Printer.printMessage("(esc) - Salir del programa");
        Printer.printMessage("Nota: Cada opción ingresada debe ir acompañada por la sigla deseada y la lista de números que desea verificar separados por espacio");
        Printer.printMessage("Por ejemplo: NMN 23 56 17 90 5 0");        
        Printer.printMessage("===============================================");
    }
    
}
