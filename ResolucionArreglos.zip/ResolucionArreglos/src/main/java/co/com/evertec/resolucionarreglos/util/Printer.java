/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.evertec.resolucionarreglos.util;

/**
 *
 * @author Mayerly Bustos R
 */
public class Printer {
    
    /**
     * Método encargado de realizar la impresión por consola del mensaje
     * pasado como parámetro.
     * 
     * @param message 
     */
    public static void printMessage(String message) {
        System.out.println(message);
    }
    
    /**
     * Método encargado de la impresión del arreglo de enteros pasado
     * por parámetro
     * @param integerArray Arreglo de enteros que se desea imprimir
     * @param message Mensaje que se muestra antes de mostrar la impresión del arreglo
     * 
     */
    public static void printArray(Integer[] integerArray, String message) {
        System.out.println(message);
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for(Integer num : integerArray) {
            sb.append(num + ", ");
        }
        int lastCommaIndex = sb.lastIndexOf(", ");
        System.out.println(sb.substring(0, lastCommaIndex).concat("]"));
    }
}
