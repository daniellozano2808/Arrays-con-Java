/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.com.evertec.resolucionarreglos.util;

/**
 *
 * @author USER
 */
public class ArrayConvertor {

    /**
     * Método encargado de realizar la conversión del array de string a array de
     * integer
     *
     * @param array Arreglo de números en formato String
     * @param initialPosition Posición en la que inician los números
     * @return Arreglo de números enteros
     */
    public static Integer[] convertStringArrayToIntegerArray(String[] array, int initialPosition) {
        if (array.length > 0) {
            Integer[] finalArray = new Integer[array.length - 1];
            for (int i = 0; i < finalArray.length; i++) {
                finalArray[i] = Integer.parseInt(array[i + 1]);
            }
            return finalArray;
        }
        return null;
    }
}
